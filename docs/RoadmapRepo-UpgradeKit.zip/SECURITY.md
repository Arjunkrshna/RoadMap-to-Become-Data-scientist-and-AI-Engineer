# Security Policy

This repository is primarily documentation.

If you discover a security issue related to any included code examples:
- Please do **not** post it publicly as an issue.
- Instead, open a private report by contacting the maintainer.

Thank you for responsible disclosure.
