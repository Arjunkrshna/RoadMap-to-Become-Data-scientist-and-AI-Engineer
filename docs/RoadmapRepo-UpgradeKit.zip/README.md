# Roadmap to Become a Data Scientist & AI Engineer

[![Markdown Lint](../../actions/workflows/markdownlint.yml/badge.svg)](../../actions/workflows/markdownlint.yml)
[![Link Check](../../actions/workflows/links.yml/badge.svg)](../../actions/workflows/links.yml)

A structured roadmap with **modules + resources + projects** to go from beginner → job-ready.

## How to use this repo
1. Start with **docs/00-start-here.md**
2. Follow the modules in **ROADMAP.md**
3. Build at least 1 project per major section (see **projects/projects.md**)
4. Track progress by checking off items in the module docs

## What you'll find
- **ROADMAP.md** — the big picture (all modules)
- **docs/** — module-by-module notes
- **resources/resources.md** — curated links
- **projects/projects.md** — portfolio-ready project ideas
- **.github/** — issue/PR templates + CI checks

## Contributing
See **CONTRIBUTING.md** — improvements, fixes, and new resources are welcome.

## License
See **LICENSE**.
