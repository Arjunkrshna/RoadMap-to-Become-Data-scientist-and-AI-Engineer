# Projects

Pick projects that prove real skill. Aim for 6–12 total.

## Beginner
1. EDA case study (one dataset, strong story)
2. Regression (forecasting / price prediction)
3. Classification (churn / fraud / spam)

## Intermediate
4. End-to-end ML pipeline (train → evaluate → deploy API)
5. Dashboard + ML insight (Streamlit or similar)

## AI Engineering (GenAI)
6. Simple RAG chatbot over your notes
7. Document Q&A with citations + eval set
8. Agent workflow (tool use, guardrails, logging)

For each project, write:
- Problem statement
- Dataset/source
- Approach
- Results (metrics)
- What you learned
- Next improvements
