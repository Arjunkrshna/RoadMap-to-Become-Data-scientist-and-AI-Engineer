# Code of Conduct

Be respectful. Be helpful. No harassment, hate speech, or personal attacks.

If there’s a problem, open an issue or contact the maintainer privately.
