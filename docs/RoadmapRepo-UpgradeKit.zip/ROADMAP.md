# Roadmap

This roadmap is split into modules. Do them in order for the smoothest learning curve.

## 00 — Start Here
- Tools: Git/GitHub, VS Code, Python, Jupyter
- Learning system: notes, spaced repetition, mini-projects

## 01 — Math for ML (practical)
- Linear algebra: vectors, matrices, dot product, eigen-intuition
- Calculus basics: derivatives, gradients, optimization intuition
- Probability basics: random variables, distributions

## 02 — Python for Data Work
- NumPy, Pandas
- Functions, modules, debugging
- Plotting (Matplotlib)

## 03 — Statistics (core)
- Descriptive stats: mean/variance, distributions
- Inferential stats: sampling, confidence intervals
- Hypothesis testing basics + A/B testing

## 04 — Data Analysis & Storytelling
- EDA patterns and common pitfalls
- Feature understanding & leakage
- Visualization that answers questions

## 05 — Machine Learning
- Regression, classification
- Cross-validation, bias/variance
- Metrics: precision/recall, ROC-AUC, RMSE
- Feature engineering + pipelines

## 06 — Deep Learning
- Neural networks, backprop intuition
- CNN basics
- Transfer learning

## 07 — GenAI Foundations
- Tokens, context, temperature
- Prompt patterns
- Embeddings & similarity search
- When fine-tuning makes sense

## 08 — RAG + Agents (AI Engineering)
- Chunking strategies, retrieval, reranking
- Vector database concepts
- Tool use / function calling
- Agent patterns + guardrails

## 09 — MLOps + Deployment
- Packaging & reproducibility
- APIs (FastAPI/Flask)
- Monitoring basics
- CI/CD for ML

## 10 — Career: Resume + Interview Prep
- Portfolio packaging
- Project storytelling
- Interview topics checklist

---

**Outcome target:** 6–12 solid projects + clear narrative + practical skills you can demo.
