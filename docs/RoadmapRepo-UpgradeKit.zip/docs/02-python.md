# 02 — Python for Data Work

Add notes + examples here.
