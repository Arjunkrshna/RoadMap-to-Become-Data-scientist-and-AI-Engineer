# 00 — Start Here

## Setup checklist
- Install Git
- Create a GitHub account
- Install VS Code
- Install Python (and optionally Anaconda)
- Setup a virtual environment

## How to study (simple loop)
Learn → Notes → Mini-exercise → Tiny project → Review.

> Add your personal study schedule here.
