# 07 — GenAI Foundations

Add notes + examples here.
