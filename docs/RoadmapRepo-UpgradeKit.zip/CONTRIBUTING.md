# Contributing Guide

Thanks for improving this roadmap!

## Ways to contribute
- Fix broken links
- Improve explanations
- Add high-quality resources (prefer official docs / well-known sources)
- Add portfolio project ideas with clear steps & expected outcome

## Pull Request checklist
- [ ] Links tested (if applicable)
- [ ] Formatting looks clean (Markdown lint passes)
- [ ] Added content in the correct module/section
